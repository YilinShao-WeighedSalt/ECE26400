#ifndef __BIT_PATTERN_H__
#define __BIT_PATTERN_H__

void print_a_byte_array(void *addr, int nelements);

#endif
