#ifndef __ADD_H__
#define __ADD_H__

long add(long i, long j);

#endif
