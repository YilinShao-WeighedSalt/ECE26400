// to understand argc and argv
// to understandd call stack

#include <stdlib.h>
#include <stdio.h>

#include "add.h"

//int main(int argc, char *argv[])
int main(int argc, char **argv)
{
   if (argc != 3) {
      fprintf(stderr, "expecting 2 arguments\n");
      return EXIT_FAILURE;
   }
/* base 10 conversion
   long i = strtol(argv[1], NULL, 10);
   long j = strtol(argv[2], NULL, 10);
*/
/* base 16 conversion
   long i = strtol(argv[1], NULL, 16);
   long j = strtol(argv[2], NULL, 16);
*/
/* base 2 conversion
*/
   long i = strtol(argv[1], NULL, 2);
   long j = strtol(argv[2], NULL, 2);
   fprintf(stdout, "%ld + %ld = %ld\n", i, j, add(i,j));
   return EXIT_SUCCESS;
}

