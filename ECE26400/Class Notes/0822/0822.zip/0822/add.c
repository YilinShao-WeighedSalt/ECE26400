#include "add.h"

long add(long i, long j)
{
   return i+j;
}
