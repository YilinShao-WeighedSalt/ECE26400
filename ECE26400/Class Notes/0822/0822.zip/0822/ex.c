// to understand argc and argv
// to understandd call stack

#include <stdlib.h>
#include <stdio.h>

//int main(int argc, char *argv[])
int main(int argc, char **argv)
{
   int i;
   for (i = 0; i < argc; i++) {
      fprintf(stdout, "%d %d %s\n", i, argc, argv[i]);
   }
   return EXIT_SUCCESS;
}
