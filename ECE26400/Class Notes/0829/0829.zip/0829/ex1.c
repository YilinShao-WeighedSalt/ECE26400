// to understand argc and argv
// to understandd call stack

#include <stdlib.h>
#include <stdio.h>

#include "add.h"

//int main(int argc, char *argv[])
int main(int argc, char **argv)
{
   if (argc != 3) {
      fprintf(stderr, "expecting 2 arguments\n");
      return EXIT_FAILURE;
   }
   long i;
   long j;
   long result;
   char *eptr;// store the address of the character that causes the conversion to failZZ
/* base 10 conversion
*/
   i = strtol(argv[1], &eptr, 10);
   fprintf(stderr, "%c %hhd\n", *eptr, eptr[0]);
   fprintf(stderr, "%s\n", eptr);
   j = strtol(argv[2], &eptr, 10);
   fprintf(stderr, "%c %hhd\n", *eptr, eptr[0]);
   fprintf(stderr, "%s\n", eptr);
   add(i, j, &result);
   fprintf(stdout, "%ld + %ld = %ld\n", i, j, result);
/* base 16 conversion
*/
   i = strtol(argv[1], &eptr, 36);
   fprintf(stderr, "%c %hhd\n", *eptr, eptr[0]);
   fprintf(stderr, "%s\n", eptr);
   j = strtol(argv[2], &eptr, 36);
   fprintf(stderr, "%c %hhd\n", *eptr, eptr[0]);
   fprintf(stderr, "%s\n", eptr);
   add(i, j, &result);
   fprintf(stdout, "%ld + %ld = %ld\n", i, j, result);
/* base 2 conversion
*/
   i = strtol(argv[1], &eptr, 2);
   fprintf(stderr, "%c %hhd\n", *eptr, eptr[0]);
   fprintf(stderr, "%s\n", eptr);
   j = strtol(argv[2], &eptr, 2);
   fprintf(stderr, "%c %hhd\n", *eptr, eptr[0]);
   fprintf(stderr, "%s\n", eptr);
   add(i, j, &result);
   fprintf(stdout, "%ld + %ld = %ld\n", i, j, result);

   return EXIT_SUCCESS;
}
