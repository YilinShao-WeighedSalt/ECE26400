#ifndef __LTOSTR_H__
#define __LTOSTR_H__

// return a string, i.e., a block of char ended with '\0'
// given a long int, and given a base int
//
char *ltostr(long n, int base);

#endif
