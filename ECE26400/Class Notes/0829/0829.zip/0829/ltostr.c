#include <stdlib.h>
#include <stdio.h>

#include "ltostr.h"

static int num_of_syms(long n, int base)
{
   int count = 0;
   if (n < 0) {
      count++;
   }
   do {
      count++;
      n = n/base;
   } while (n != 0);
   return count;
}

// return a string, i.e., a block of char ended with '\0'
// given a long int, and given a base int
//
// first, count the number of chars required to store the number as a string
// allocate the space for the string
// store the symbols representing the number in the string 
char *ltostr(long n, int base)
{
   int string_size = num_of_syms(n, base) + 1; // additional char for '\0'
   fprintf(stderr, "number of symbols %d\n", string_size);

   // to be continued

   return NULL;
}
