#ifndef __ADD_H__
#define __ADD_H__

void add(long, long, long *);

#endif
